module.exports = {
    // GET /hello
    signup: async ctx => {
      // Store the new user in database.
      //const user = await User.create(ctx.params);
  
      // Send an email to validate his subscriptions.
      strapi.services.email.send(
        'mody.kane16@gmail.com',
        'mody.kane16@gmail.com',
        'Reset Password',
        'http:/localhost:1337/admin/plugins/users-permissions/auth/reset-password'
      );
  
      // Send response to the server.
      ctx.send({
        ok: true,
      });
    },
  };