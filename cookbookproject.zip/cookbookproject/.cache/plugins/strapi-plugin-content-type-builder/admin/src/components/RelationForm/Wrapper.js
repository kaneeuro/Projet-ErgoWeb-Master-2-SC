import styled from 'styled-components';

const Wrapper = styled.div`
  width: 100%;
  display: flex;
  padding: 2.7rem 15px 3.3rem 15px;
`;

export default Wrapper;
