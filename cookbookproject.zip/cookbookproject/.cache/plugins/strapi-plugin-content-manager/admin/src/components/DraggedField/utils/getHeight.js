const getHeight = withLongerHeight => (withLongerHeight ? '102px' : '30px');

export default getHeight;
