import { createContext } from 'react';

const EditViewDataManagerContext = createContext();

export default EditViewDataManagerContext;
