export class User {
    //id : string;
    isConnected : boolean;
    confirmed : boolean;
    blocked : boolean;
    telephone : number;
    bio : string;
    prenom : string;
    pays : string;
    nom : string;
    password : string;
    adresse : string;
    ville : string;
    username : string;
    datenaissance : string;
    profession : string;
    email : string;
    sexe : string;
    /* role = {
         _id : "5e16116b997f6e90792e96f4",
         name : "Authenticated"
    }; */
    
}
