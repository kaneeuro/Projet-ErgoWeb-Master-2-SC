import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
//import {  FileUploader } from 'ng2-file-upload/ng2-file-upload';

//const uploadAPI = 'http://localhost:4000/api/upload'; // better use a service class

@Injectable({
  providedIn: 'root'
})
export class UserService {

  baseUri : string = 'http://localhost:1337';
  authUri : string = 'http://localhost:1337/auth/local';
  headers = new HttpHeaders().set('Content-Type', 'application/json');

  constructor(private http: HttpClient) { }

  // Create user
  createUser(data): Observable<any> {
    let url = `${this.baseUri}/users`;
    return this.http.post(url, data, {headers: this.headers})
      .pipe(
        catchError(this.errorMgmt)
      )
  }

  // Create user
  createRecette(data): Observable<any> {
    let url = `${this.baseUri}/recettes`;
    return this.http.post(url, data, {headers: this.headers})
      .pipe(
        catchError(this.errorMgmt)
      )
  }

  // Authentication user
  authenticationUser(data): Observable<any> {
    let url = `${this.authUri}`;
    return this.http.post(url, data, {headers: this.headers})
      .pipe(
        catchError(this.errorMgmt)
      )
  }

  // Get all users
  getUsers() {
    return this.http.get(`${this.baseUri}/users`);
  }

  // Get all recettes
  getRecettes() {
    return this.http.get(`${this.baseUri}/recettes`);
  }

  // Get user by id
  getUserById(id): Observable<any> {
    let url = `${this.baseUri}/users/${id}`;
    return this.http.get(url, {headers: this.headers}).pipe(
      map((res: Response) => {
        return res || {}
      }),
      catchError(this.errorMgmt)
    )
  }

  // Get recette by id
  getRecetteById(id): Observable<any> {
    let url = `${this.baseUri}/recettes/${id}`;
    return this.http.get(url, {headers: this.headers}).pipe(
      map((res: Response) => {
        return res || {}
      }),
      catchError(this.errorMgmt)
    )
  }

  // Get user by email
  getUserByEmail(email): Observable<any> {
    let url = `${this.baseUri}/users?email=${email}`;
    return this.http.get(url, {headers: this.headers}).pipe(
      map((res: Response) => {
        return res || {}
      }),
      catchError(this.errorMgmt)
    )
  }

  // Get recetttes by nom
  getRecettesByNom(nom): Observable<any> {
    let url = `${this.baseUri}/recettes?nom_contains=${nom}`;
    return this.http.get(url, {headers: this.headers}).pipe(
      map((res: Response) => {
        return res || {}
      }),
      catchError(this.errorMgmt)
    )
  }

  // Update user
  updateUser(id, data): Observable<any> {
    let url = `${this.baseUri}/users/${id}`;
    return this.http.put(url, data, { headers: this.headers }).pipe(
      catchError(this.errorMgmt)
    )
  }

  // Reset user password
  resetPasswordUser(id, data): Observable<any> {
    let url = `${this.baseUri}/users/${id}`;
    return this.http.put(url, data, { headers: this.headers }).pipe(
      catchError(this.errorMgmt)
    )
  }

  // Delete user
  deleteUser(id): Observable<any> {
    let url = `${this.baseUri}/users/${id}`;
    return this.http.delete(url, { headers: this.headers }).pipe(
      catchError(this.errorMgmt)
    )
  }

  // Error handling 
  errorMgmt(error: HttpErrorResponse) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }

}
