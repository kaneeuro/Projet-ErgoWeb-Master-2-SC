import { Router } from '@angular/router';
import { UserService } from './../../services/user.service';
import { Component, OnInit, NgZone } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import Swal from 'sweetalert2';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {
  submitted = false;
  userForm: FormGroup;
  email: string;
  password: string;
  confirmpassword: string;
  

  constructor(
    public fb: FormBuilder,
    private router: Router,
    private ngZone: NgZone,
    private userService: UserService
  ) { 
    this.mainForm();
  }

  ngOnInit() {
  }

  mainForm() {
    this.userForm = this.fb.group({
      email: ['', [Validators.required]],
      password: ['', [Validators.required]],
      confirmpassword: ['', [Validators.required]]
    })
  }

  // Getter to access form control
  get myForm(){
    return this.userForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    if (!this.userForm.valid) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Veuillez remplir tous les champs!',
      })
      return false;
    } else {
      if (this.password == this.confirmpassword) {
        this.userService.getUserByEmail(this.email).subscribe(
          (res) => {
            console.log(res)
            if (res[0] != null) {
                this.userService.updateUser(res[0]._id, JSON.stringify(this.userForm.value)).subscribe(
                  (res) => {
                    Swal.fire({
                      icon: 'success',
                      title: 'Modification mot de passe',
                      text: 'Vous pouvez vous connecter avec vos nouveaux identifiants!',
                    })
                    this.ngZone.run(() => this.router.navigateByUrl('/login'))
                  }, (error) => {
                    console.log(error);
                  });
              } else {
                Swal.fire({
                  icon: 'error',
                  title: 'Oops...',
                  text: 'Votre email ne correspond à aucun utilisateur!',
                })
              }
            }, (error) => {
              console.log(error);
            });
          } else {
            Swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'Les deux mots de passe ne correspondent pas!',
            })
          }
      
    }
  }

  Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 5000,
    timerProgressBar: true,
    onOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer)
      toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
  })

}
