import { Router } from '@angular/router';
import { UserService } from './../../services/user.service';
import { Component, OnInit, NgZone } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import Swal from 'sweetalert2';

@Component({
  selector: 'app-accueilconnected',
  templateUrl: './accueilconnected.component.html',
  styleUrls: ['./accueilconnected.component.css']
})
export class AccueilconnectedComponent implements OnInit {

  recettes:any = [];
  rechercherecettes:any = [];
  baseUri : string = 'http://localhost:1337/';
  //baseUriServer : string = 'http://localhost:4000/server/uploads/';

  submitted = 1;
  userForm: FormGroup;
  nom: string;

  constructor(public fb: FormBuilder,
    private router: Router,
    private ngZone: NgZone,
    private userService: UserService) {
      
      //this.submitted = false;
      this.getRecettes();

  }

  ngOnInit() {
  }

  getRecettes(){
    this.userService.getRecettes().subscribe((res) => {
      if (res[0] != null) {
        this.submitted = 1;
        this.recettes = res;
        for (let index = 0; index < this.recettes.length; index++) {
          this.recettes[index]['file'].replace("C:/fakepath/", "");
          if (this.recettes[index]['file'].includes('C:')) {
            console.log(this.recettes[index]['file'].substring(12));
            this.recettes[index]['file']=this.recettes[index]['file'].substring(12);
          }
          //console.log(this.recettes[index]['file'].substring(12));
        }
        console.log(this.recettes)
        } else {
          this.submitted = 3;
          console.log(this.submitted)
          this.ngZone.run(() => this.router.navigateByUrl('/home'))
          /* Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Il n\'y a pas de recettes correspondant à : '+this.nom,
          }) */
        }
    })    
  }


  onSubmit() {
    if (this.nom == null) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Veuillez remplir le champ de recherche!',
      })
      return false;
    } else {
        this.userService.getRecettesByNom(this.nom).subscribe(
          (res) => {
            if (res[0] != null) {
              this.submitted = 2;
              console.log(this.submitted)
              console.log(res)
              this.rechercherecettes = res;
              for (let index = 0; index < this.rechercherecettes.length; index++) {
                this.rechercherecettes[index]['file'].replace("C:/fakepath/", "");
                if (this.rechercherecettes[index]['file'].includes('C:')) {
                  console.log(this.rechercherecettes[index]['file'].substring(12));
                  this.rechercherecettes[index]['file']=this.rechercherecettes[index]['file'].substring(12);
                }
                //console.log(this.recettes[index]['file'].substring(12));
              }
              console.log(this.rechercherecettes)
              //console.log(this.rechercherecettes[7].file.split('C:\\fakepath\\'));
              this.ngZone.run(() => this.router.navigateByUrl('/home'))
              } else {
                this.submitted = 3;
                console.log(this.submitted)
                this.ngZone.run(() => this.router.navigateByUrl('/home'))
                /* Swal.fire({
                  icon: 'error',
                  title: 'Oops...',
                  text: 'Il n\'y a pas de recettes correspondant à : '+this.nom,
                }) */
              }
            }, (error) => {
              console.log(error);
              Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Une erreur s\'est produite... Veuillez réessayer!',
              })
            });
          
      
    }
  }

  Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 5000,
    timerProgressBar: true,
    onOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer)
      toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
  })

}
