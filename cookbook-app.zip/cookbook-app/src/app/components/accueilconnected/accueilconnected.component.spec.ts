import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccueilconnectedComponent } from './accueilconnected.component';

describe('AccueilconnectedComponent', () => {
  let component: AccueilconnectedComponent;
  let fixture: ComponentFixture<AccueilconnectedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccueilconnectedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccueilconnectedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
