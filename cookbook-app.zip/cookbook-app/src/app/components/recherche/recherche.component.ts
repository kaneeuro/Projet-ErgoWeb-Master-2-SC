import { ActivatedRoute, Router } from "@angular/router";
import { UserService } from './../../services/user.service';
import { Component, OnInit, NgZone } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import Swal from 'sweetalert2';

@Component({
  selector: 'app-recherche',
  templateUrl: './recherche.component.html',
  styleUrls: ['./recherche.component.css']
})
export class RechercheComponent implements OnInit {

  recette:any = [];
  tags = [];
  ingredients = [];
  ustensiles = [];
  instructions = [];
  baseUri : string = 'http://localhost:1337/';

  submitted = false;
  userForm: FormGroup;
  

  constructor(
    public fb: FormBuilder,
    private router: Router,
    private ngZone: NgZone,
    private actRoute: ActivatedRoute,
    private userService: UserService
  ) { 
    //this.mainForm();
  }

  ngOnInit() {
    let id = this.actRoute.snapshot.paramMap.get('id');
    this.getRecetteById(id);
  }

  getRecetteById(id) {
    this.userService.getRecetteById(id).subscribe(res => {
      console.log(res)
      this.recette = res
      this.tags = res.tags.split(',');
      this.ingredients = res.ingredients.split(',');
      this.ustensiles = res.ustensiles.split(',');
      this.instructions = res.instructions.split('\n\n');
    });
  }

  onSubmit() {
    this.submitted = true;
    if (!this.userForm.valid) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Veuillez remplir ce champ pour effectuer une recherche!',
      })
      return false;
    } else {
      console.log(this.userForm.value);
      console.log(JSON.stringify(this.userForm.value));
      this.userService.authenticationUser(JSON.stringify(this.userForm.value)).subscribe(
        (res) => {
          console.log(res)
          console.log('User successfully authenticated!')
          
          this.ngZone.run(() => this.router.navigateByUrl('/recherche'))
        }, (error) => {
          console.log(error);
          //alert("Email ou mot de passe incorrect!");
        });
      
    }
  }

}
