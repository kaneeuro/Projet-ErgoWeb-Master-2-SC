import { Router } from '@angular/router';
import { UserService } from './../../services/user.service';
import { Component, OnInit, NgZone } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import Swal from 'sweetalert2';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  submitted = false;
  userForm: FormGroup;
  userSexe:any = ['Homme', 'Femme', 'Autre'];
  userState: any;
  

  constructor(
    public fb: FormBuilder,
    private router: Router,
    private ngZone: NgZone,
    private userService: UserService
  ) { 
    this.mainForm();
  }

  ngOnInit() {
  }

  mainForm() {
    this.userForm = this.fb.group({
      prenom: ['', [Validators.required]],
      nom: ['', [Validators.required]],
      username: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$')]],
      password: ['', [Validators.required]],
      telephone: ['', [Validators.pattern('^[0-9]+$')]],
      sexe: ['', [Validators.required]],
      datenaissance: [''],
      isConnected: true,
      confirmed: true,
      adresse: ['']
    })
  }

  // Choose sexe with select dropdown
  updateSexe(e){
    this.userForm.get('sexe').setValue(e, {
      onlySelf: true
    })
  }

  // Getter to access form control
  get myForm(){
    return this.userForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    if (!this.userForm.valid) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Veuillez remplir tous les champs!',
      })
      return false;
    } else {
      console.log(this.userForm.value);
      console.log(JSON.stringify(this.userForm.value));
      this.userService.createUser(JSON.stringify(this.userForm.value)).subscribe(
        (res) => {
          console.log(res)
          console.log('User successfully registred!')

          this.userState = res;
          localStorage.setItem('user', JSON.stringify(this.userState));
          JSON.parse(localStorage.getItem('user'));

          this.Toast.fire({
            icon: 'success',
            title: 'Bienvenue sur Cookbook!'
          })
          this.ngZone.run(() => this.router.navigateByUrl('/home'))
        }, (error) => {
          localStorage.setItem('user', null);
          JSON.parse(localStorage.getItem('user'));
          console.log(error);
        });
    }
  }


  Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 5000,
    timerProgressBar: true,
    onOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer)
      toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
  })

}
