import { Component, OnInit } from '@angular/core';
import { UserService } from './../../services/user.service';

@Component({
  selector: 'app-accueil',
  templateUrl: './accueil.component.html',
  styleUrls: ['./accueil.component.css']
})
export class AccueilComponent implements OnInit {

  recettes:any = [];
  baseUri : string = 'http://localhost:1337/';

  constructor(private userService: UserService) {
    this.getRecettes();
   }

  ngOnInit() {
  }

  getRecettes(){
    this.userService.getRecettes().subscribe((data) => {
      
     this.recettes = data;
     for (let index = 0; index < this.recettes.length; index++) {
       this.recettes[index]['file'].replace("C:/fakepath/", "");
       if (this.recettes[index]['file'].includes('C:')) {
        console.log(this.recettes[index]['file'].substring(12));
        this.recettes[index]['file']=this.recettes[index]['file'].substring(12);
       }
       //console.log(this.recettes[index]['file'].substring(12));
     }
     console.log(this.recettes)
    })    
  }


}
