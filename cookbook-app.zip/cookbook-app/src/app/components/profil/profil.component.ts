import { Router } from '@angular/router';
import { UserService } from './../../services/user.service';
import { Component, OnInit, NgZone } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import Swal from 'sweetalert2';

@Component({
  selector: 'app-profil',
  templateUrl: './profil.component.html',
  styleUrls: ['./profil.component.css']
})
export class ProfilComponent implements OnInit {
  
  user : any;
  recettes:any = [];
  rechercherecettes:any = [];
  baseUri : string = 'http://localhost:1337/';
  //baseUriServer : string = 'http://localhost:4000/server/uploads/';

  submitted = 1;
  userForm: FormGroup;
  nom: string;

  
  constructor(public fb: FormBuilder,
    private router: Router,
    private ngZone: NgZone,
    private userService: UserService) {
      
      //this.submitted = false;
      this.getRecettes();

  }

  ngOnInit() {
  this.user = JSON.parse(localStorage.getItem('user'));
  }

  deleteUser(){
    this.userService.deleteUser(this.user.user._id).subscribe(
      (res) => {
        console.log(res)
        Swal.fire({
          icon: 'success',
          title: 'Gestion profil',
          text: 'Votre compte a été supprimé!',
        })
        this.ngZone.run(() => this.router.navigateByUrl('/accueil'))
        }, (error) => {
          console.log(error);
        });
  }

  getRecettes(){
    this.userService.getRecettes().subscribe((res) => {
      if (res[0] != null) {
        this.submitted = 1;
        this.recettes = res;
        for (let index = 0; index < this.recettes.length; index++) {
          this.recettes[index]['file'].replace("C:/fakepath/", "");
          if (this.recettes[index]['file'].includes('C:')) {
            console.log(this.recettes[index]['file'].substring(12));
            this.recettes[index]['file']=this.recettes[index]['file'].substring(12);
          }
          //console.log(this.recettes[index]['file'].substring(12));
        }
        console.log(this.recettes)
        } else {
          this.submitted = 3;
          console.log(this.submitted)
          this.ngZone.run(() => this.router.navigateByUrl('/home'))
          /* Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Il n\'y a pas de recettes correspondant à : '+this.nom,
          }) */
        }
    })    
  }

}
