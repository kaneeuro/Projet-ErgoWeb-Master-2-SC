import { Router } from '@angular/router';
import { UserService } from './../../services/user.service';
import { Component, OnInit, NgZone } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import Swal from 'sweetalert2';
import {  FileUploader } from 'ng2-file-upload';

const uploadAPI = 'http://localhost:4000/api/upload'; // better use a service class

@Component({
  selector: 'app-ajoutrecette',
  templateUrl: './ajoutrecette.component.html',
  styleUrls: ['./ajoutrecette.component.css']
})
export class AjoutrecetteComponent implements OnInit {
  submitted = false;
  userForm: FormGroup;
  userDifficulte:any = ['Très facile', 'Facile', 'Moyen', 'Difficile', 'Très difficile']
  public uploader: FileUploader = new FileUploader({ url: uploadAPI, itemAlias: 'file' });
  user = JSON.parse(localStorage.getItem('user'));

  constructor(
    public fb: FormBuilder,
    private router: Router,
    private ngZone: NgZone,
    private userService: UserService
  ) { 
    this.mainForm();
  }

  ngOnInit() {
    console.log(this.user.user._id);
  }

  mainForm() {
    this.userForm = this.fb.group({
      nom: ['', [Validators.required]],
      file: ['', [Validators.required]],
      ingredients: ['', [Validators.required]],
      instructions: ['', [Validators.required]],
      ustensiles: ['', [Validators.required]],
      tags: ['', [Validators.required]],
      tempspreparation: ['', [Validators.required]],
      tempscuisson: ['', [Validators.required]],
      nbpersonnes: ['', [Validators.required]],
      visibilite: ['', [Validators.required]],
      difficulte: ['', [Validators.required]],
      favoris: ['', [Validators.required]],
      calories: [''],
      proteins: [''],
      fat: [''],
      saturates: [''],
      carbs: [''],
      sugar: [''],
      salt: [''],
      user: this.user.user._id,
      fibres: ['']
    })
  }

  // Choose Difficulte with select dropdown
  updateDifficulte(e){
    this.userForm.get('difficulte').setValue(e, {
      onlySelf: true
    })
  }

  // Getter to access form control
  get myForm(){
    return this.userForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    if (!this.userForm.valid) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Veuillez remplir tous les champs obligatoires!',
      })
      return false;
    } else {
      console.log(this.userForm.value);
      console.log(JSON.stringify(this.userForm.value));
      this.uploader.onAfterAddingFile = (file) => { file.withCredentials = false; };
      this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
          console.log('FileUpload:uploaded successfully:', item, status, response);
          //alert('Your file has been uploaded successfully');
      };
      this.userService.createRecette(JSON.stringify(this.userForm.value)).subscribe(
        (res) => {
          console.log(res)
          console.log('Votre recette a été bien ajoutée!')
          
          Swal.fire({
            icon: 'success',
            title: 'Ajout recette',
            text: 'Votre recette a été bien ajoutée!',
          })
          
          this.ngZone.run(() => this.router.navigateByUrl('/home'))
        }, (error) => {
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Une erreur s\'est produite, veuillez réessayer!',
          })
          console.log(error);
        });
    }
  }


  Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 5000,
    timerProgressBar: true,
    onOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer)
      toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
  })

}
