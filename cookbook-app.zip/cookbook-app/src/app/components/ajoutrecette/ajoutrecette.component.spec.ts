import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AjoutrecetteComponent } from './ajoutrecette.component';

describe('AjoutrecetteComponent', () => {
  let component: AjoutrecetteComponent;
  let fixture: ComponentFixture<AjoutrecetteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AjoutrecetteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AjoutrecetteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
