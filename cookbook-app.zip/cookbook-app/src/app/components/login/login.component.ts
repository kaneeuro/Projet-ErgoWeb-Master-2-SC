import { Router } from '@angular/router';
import { UserService } from './../../services/user.service';
import { Component, OnInit, NgZone } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  submitted = false;
  userForm: FormGroup;
  userState: any;

  constructor(
    public fb: FormBuilder,
    private router: Router,
    private ngZone: NgZone,
    private userService: UserService
  ) { 
    this.mainForm();
  }

  ngOnInit() {
  }

  mainForm() {
    this.userForm = this.fb.group({
      identifier: ['', [Validators.required]],
      password: ['', [Validators.required]]
    })
  }

  // Getter to access form control
  get myForm(){
    return this.userForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    if (!this.userForm.valid) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Veuillez remplir tous les champs!',
      })
      return false;
    } else {
      console.log(this.userForm.value);
      console.log(JSON.stringify(this.userForm.value));
      this.userService.authenticationUser(JSON.stringify(this.userForm.value)).subscribe(
        (res) => {
          console.log(res)
          console.log('User successfully authenticated!')

          this.userState = res;
          localStorage.setItem('user', JSON.stringify(this.userState));
          JSON.parse(localStorage.getItem('user'));

          this.Toast.fire({
            icon: 'success',
            title: 'Bienvenue sur Cookbook!'
          })
          
          this.ngZone.run(() => this.router.navigateByUrl('/home'))
        }, (error) => {
          localStorage.setItem('user', null);
          JSON.parse(localStorage.getItem('user'));
          
          console.log(error);
          //alert("Email ou mot de passe incorrect!");
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Email ou mot de passe incorrect!',
          })
        });
      
    }
  }

  Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 5000,
    timerProgressBar: true,
    onOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer)
      toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
  })

}
