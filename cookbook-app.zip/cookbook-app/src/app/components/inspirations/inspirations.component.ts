import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inspirations',
  templateUrl: './inspirations.component.html',
  styleUrls: ['./inspirations.component.css']
})
export class InspirationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
