import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccueilComponent } from './components/accueil/accueil.component';
import { AccueilconnectedComponent } from './components/accueilconnected/accueilconnected.component';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { RecettesComponent } from './components/recettes/recettes.component';
import { InspirationsComponent } from './components/inspirations/inspirations.component';
import { VideosComponent } from './components/videos/videos.component';
import { ActusComponent } from './components/actus/actus.component';
import { ForgotpasswordComponent } from './components/forgotpassword/forgotpassword.component';
import { RechercheComponent } from './components/recherche/recherche.component';
import { AjoutrecetteComponent } from './components/ajoutrecette/ajoutrecette.component';
import { ProfilComponent } from './components/profil/profil.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'accueil' },
  { path: 'accueil', component: AccueilComponent },
  { path: 'home', component: AccueilconnectedComponent },
  { path: 'login', component: LoginComponent },
  { path: 'recettes', component: RecettesComponent },
  { path: 'inspirations', component: InspirationsComponent },
  { path: 'videos', component: VideosComponent },
  { path: 'actus', component: ActusComponent },
  { path: 'signup', component: SignupComponent } ,
  { path: 'consultation-recette/:id', component: RechercheComponent } ,
  { path: 'ajout-recette', component: AjoutrecetteComponent } ,
  { path: 'profil', component: ProfilComponent } ,
  { path: 'forgot-password', component: ForgotpasswordComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
