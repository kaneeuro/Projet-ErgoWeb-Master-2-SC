import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FileUploadModule } from 'ng2-file-upload';

import { SweetAlert2Module } from '@sweetalert2/ngx-sweetalert2';

import { UserService } from './services/user.service';

import { AppComponent } from './app.component';
import { AccueilComponent } from './components/accueil/accueil.component';
import { AccueilconnectedComponent } from './components/accueilconnected/accueilconnected.component';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { RecettesComponent } from './components/recettes/recettes.component';
import { InspirationsComponent } from './components/inspirations/inspirations.component';
import { VideosComponent } from './components/videos/videos.component';
import { ActusComponent } from './components/actus/actus.component';
import { ForgotpasswordComponent } from './components/forgotpassword/forgotpassword.component';
import { RechercheComponent } from './components/recherche/recherche.component';
import { AjoutrecetteComponent } from './components/ajoutrecette/ajoutrecette.component';
import { ProfilComponent } from './components/profil/profil.component';

@NgModule({
  declarations: [
    AppComponent,
    AccueilComponent,
    AccueilconnectedComponent,
    LoginComponent,
    SignupComponent,
    RecettesComponent,
    InspirationsComponent,
    VideosComponent,
    ActusComponent,
    ForgotpasswordComponent,
    RechercheComponent,
    AjoutrecetteComponent,
    ProfilComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    SweetAlert2Module,
    FileUploadModule
  ],
  providers: [
    UserService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
